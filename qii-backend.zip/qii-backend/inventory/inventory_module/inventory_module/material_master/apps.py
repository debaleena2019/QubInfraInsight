from django.apps import AppConfig


class MaterialMasterConfig(AppConfig):
    name = 'material_master'
