from django.contrib import admin
from .models import mat_master

# Register your models here.
admin.site.register(mat_master)
