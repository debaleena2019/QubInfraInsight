from django.apps import AppConfig


class MaterialUnitConfig(AppConfig):
    name = 'material_unit'
