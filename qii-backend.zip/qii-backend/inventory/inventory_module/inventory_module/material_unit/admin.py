from django.contrib import admin
from .models import mat_unit

# Register your models here.
admin.site.register(mat_unit)
