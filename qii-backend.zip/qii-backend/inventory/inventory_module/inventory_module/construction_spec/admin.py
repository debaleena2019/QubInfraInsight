from django.contrib import admin
from .models import const_spec

# Register your models here.
admin.site.register(const_spec)
