from django.apps import AppConfig


class ConstructionSpecConfig(AppConfig):
    name = 'construction_spec'
