from django.apps import AppConfig


class ConstructionSpecMatConfig(AppConfig):
    name = 'construction_spec_mat'
