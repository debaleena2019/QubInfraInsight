from django.contrib import admin
from .models import const_spec_mat

# Register your models here.
admin.site.register(const_spec_mat)
