from django.apps import AppConfig


class PoPhoneConfig(AppConfig):
    name = 'po_phone'
