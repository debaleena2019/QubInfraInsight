from django.apps import AppConfig


class PoProjectConfig(AppConfig):
    name = 'po_project'
