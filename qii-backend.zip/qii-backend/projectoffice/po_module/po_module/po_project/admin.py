from django.contrib import admin
from .models import po_project

# Register your models here.
admin.site.register(po_project)
