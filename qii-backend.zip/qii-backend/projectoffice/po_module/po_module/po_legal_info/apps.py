from django.apps import AppConfig


class PoLegalInfoConfig(AppConfig):
    name = 'po_legal_info'
