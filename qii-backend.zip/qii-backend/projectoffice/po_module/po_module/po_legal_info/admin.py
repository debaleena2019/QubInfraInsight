from django.contrib import admin
from .models import po_legal_info

# Register your models here.
admin.site.register(po_legal_info)
