from django.contrib import admin
from .models import po_address

# Register your models here.
admin.site.register(po_address)
