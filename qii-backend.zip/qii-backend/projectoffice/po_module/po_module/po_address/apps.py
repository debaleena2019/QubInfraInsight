from django.apps import AppConfig


class PoAddressConfig(AppConfig):
    name = 'po_address'
