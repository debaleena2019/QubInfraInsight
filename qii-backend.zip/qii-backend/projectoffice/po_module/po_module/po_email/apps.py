from django.apps import AppConfig


class PoEmailConfig(AppConfig):
    name = 'po_email'
