from django.contrib import admin
from .models import po_email

# Register your models here.
admin.site.register(po_email)
