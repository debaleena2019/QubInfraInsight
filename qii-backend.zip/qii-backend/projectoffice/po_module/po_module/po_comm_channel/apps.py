from django.apps import AppConfig


class PoCommChannelConfig(AppConfig):
    name = 'po_comm_channel'
