from django.apps import AppConfig


class PoAdditonalAttributeConfig(AppConfig):
    name = 'po_additonal_attribute'
