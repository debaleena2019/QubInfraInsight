from django.contrib import admin
from .models import po_additional_att

# Register your models here.
admin.site.register(po_additional_att)
