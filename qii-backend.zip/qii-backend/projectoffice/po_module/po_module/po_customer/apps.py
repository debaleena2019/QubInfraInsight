from django.apps import AppConfig


class PoCustomerConfig(AppConfig):
    name = 'po_customer'
