from django.apps import AppConfig


class PoProjectAttributesConfig(AppConfig):
    name = 'po_project_attributes'
