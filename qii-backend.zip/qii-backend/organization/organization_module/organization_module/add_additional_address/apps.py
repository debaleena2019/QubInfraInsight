from django.apps import AppConfig


class AddAdditionalAddressConfig(AppConfig):
    name = 'add_additional_address'
