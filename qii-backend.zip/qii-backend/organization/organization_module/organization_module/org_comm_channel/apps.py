from django.apps import AppConfig


class OrgCommChannelConfig(AppConfig):
    name = 'org_comm_channel'
