from django.contrib import admin
from .models import orgcommchannel

# Register your models here.
admin.site.register(orgcommchannel)
