from django.apps import AppConfig


class OrgEmailConfig(AppConfig):
    name = 'org_email'
