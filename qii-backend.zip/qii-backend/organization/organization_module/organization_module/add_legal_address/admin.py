from django.contrib import admin
from .models import legaladdress

# Register your models here.
admin.site.register(legaladdress)
