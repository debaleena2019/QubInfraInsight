from django.apps import AppConfig


class AddLegalAddressConfig(AppConfig):
    name = 'add_legal_address'
