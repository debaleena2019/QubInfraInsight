from django.apps import AppConfig


class OrgAddressConfig(AppConfig):
    name = 'org_address'
