from django.contrib import admin
from .models import orgAddress

# Register your models here.
admin.site.register(orgAddress)
