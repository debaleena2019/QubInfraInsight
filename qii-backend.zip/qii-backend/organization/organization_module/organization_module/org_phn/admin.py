from django.contrib import admin
from .models import orgphone

# Register your models here.
admin.site.register(orgphone)
