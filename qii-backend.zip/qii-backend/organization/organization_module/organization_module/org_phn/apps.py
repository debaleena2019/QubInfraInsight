from django.apps import AppConfig


class OrgPhnConfig(AppConfig):
    name = 'org_phn'
