from django.contrib import admin
from .models import org

# Register your models here.
admin.site.register(org)
