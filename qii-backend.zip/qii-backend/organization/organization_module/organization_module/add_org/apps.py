from django.apps import AppConfig


class AddOrgConfig(AppConfig):
    name = 'add_org'
